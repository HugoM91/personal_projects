package pt.upskills.projeto.rogue.utils;

/**
 * @author POO2016
 * 
 * Cardinal directions
 *
 */
public enum Direction {
	LEFT, UP, RIGHT, DOWN;

	public Vector2D asVector() {
		if(this==Direction.UP){

		}
		if(this==Direction.DOWN){

		}
		if(this==Direction.LEFT){

		}
		if(this==Direction.RIGHT){

		}
		return null;
	}
}
